using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SafeExamBrowser.Communication.UnitTests")]
[assembly: AssemblyDescription("Safe Exam Browser")]
[assembly: AssemblyCompany("ETH Zürich")]
[assembly: AssemblyProduct("SafeExamBrowser.Communication.UnitTests")]
[assembly: AssemblyCopyright("Copyright © 2025 ETH Zürich, IT Services")]

[assembly: ComVisible(false)]

[assembly: Guid("21137d66-7d01-4327-92d2-0304c25cd7df")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0.0")]
