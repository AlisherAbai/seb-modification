using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SafeExamBrowser.Runtime.UnitTests")]
[assembly: AssemblyDescription("Safe Exam Browser")]
[assembly: AssemblyCompany("ETH Zürich")]
[assembly: AssemblyProduct("SafeExamBrowser.Runtime.UnitTests")]
[assembly: AssemblyCopyright("Copyright © 2025 ETH Zürich, IT Services")]

[assembly: ComVisible(false)]

[assembly: Guid("b716a8b2-df72-4143-9941-25e033089f5f")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0.0")]
